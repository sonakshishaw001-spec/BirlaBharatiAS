import json
import os
import re
import sys
import urllib.request

API_KEY = os.environ.get("OPENROUTER_API_KEY")

if not API_KEY:
    print("ERROR: OPENROUTER_API_KEY is not set.")
    print("Run:")
    print("set OPENROUTER_API_KEY=YOUR_API_KEY")
    sys.exit(1)

prompt = " ".join(sys.argv[1:])

if not prompt:
    print('Usage: python agent\\generator.py "your game idea"')
    sys.exit(1)

print("\n🎮 GAMELOOP GENERATOR")
print("Prompt:", prompt)
print("\n🤖 Generating game...\n")

instruction = f"""
You are GAMELOOP, an autonomous game-generation agent.

The user wants this game:

"{prompt}"

Generate a small COMPLETE browser game.

Requirements:
- HTML5
- JavaScript
- Canvas 2D
- No external assets
- No external libraries
- Player movement
- Collision
- Score
- Clear win condition
- Clear loss condition

CANVAS REQUIREMENTS:
- The gameplay canvas MUST use an internal resolution of 800x450.
- The canvas must be 16:9.
- Do NOT create a tiny canvas or a canvas shorter than 400 pixels.
- The entire gameplay area must fit inside the canvas.
- The canvas may scale responsively with CSS, but its internal width must be 800 and height must be 450.
- Keep the HUD and gameplay inside the canvas.

CODE REQUIREMENTS:
- Keep the implementation compact and reliable.
- Make keyboard movement work with WASD and Arrow Keys.
- Keep the player inside canvas boundaries.
- Avoid unnecessary complexity.
- Do not include explanations outside the requested JSON.

Return ONLY valid JSON.
Do not use markdown.
Do not use code fences.
Do not add comments or prose before or after the JSON.

Return exactly:

{{
  "files": [
    {{
      "path": "index.html",
      "content": "FULL HTML FILE"
    }},
    {{
      "path": "game.js",
      "content": "FULL JAVASCRIPT FILE"
    }}
  ]
}}
"""

url = "https://openrouter.ai/api/v1/chat/completions"

payload = {
    "model": "openrouter/free",
    "messages": [
        {
            "role": "user",
            "content": instruction
        }
    ],
    "max_tokens": 12000
}

data = json.dumps(payload).encode("utf-8")

request = urllib.request.Request(
    url,
    data=data,
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    },
    method="POST"
)

try:
    with urllib.request.urlopen(request, timeout=90) as response:
        result = json.loads(response.read().decode("utf-8"))

except Exception as e:
    print("\n❌ OpenRouter request failed:")
    print(e)
    sys.exit(1)

try:
    text = result["choices"][0]["message"]["content"].strip()

except Exception:
    print("\n❌ Unexpected OpenRouter response:")
    print(json.dumps(result, indent=2))
    sys.exit(1)


# Remove common markdown wrappers and accidental wrapper artifacts.
text = text.replace("```json", "").replace("```", "").strip()
text = text.replace("</arg_value>", "").replace("<arg_value>", "").strip()


def parse_model_json(raw_text):
    """Parse JSON while tolerating harmless trailing model artifacts."""
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError:
        pass

    # Find the first JSON object and decode only that object.
    start = raw_text.find("{")

    if start == -1:
        raise json.JSONDecodeError(
            "No JSON object found",
            raw_text,
            0
        )

    decoder = json.JSONDecoder()
    game, _ = decoder.raw_decode(raw_text[start:])
    return game


try:
    game = parse_model_json(text)

except json.JSONDecodeError:
    print("\n❌ Model returned invalid JSON.")
    print(text)
    sys.exit(1)


if not isinstance(game, dict) or not isinstance(game.get("files"), list):
    print("\n❌ Invalid game format.")
    sys.exit(1)


os.makedirs("generated", exist_ok=True)


def normalize_canvas(html):
    """Safety net: enforce an 800x450 internal canvas."""

    def fix_canvas(match):
        tag = match.group(0)

        tag = re.sub(
            r'\bwidth\s*=\s*["\']?\d+["\']?',
            'width="800"',
            tag,
            count=1,
            flags=re.I
        )

        if not re.search(r'\bwidth\s*=', tag, re.I):
            tag = tag[:-1] + ' width="800">'

        tag = re.sub(
            r'\bheight\s*=\s*["\']?\d+["\']?',
            'height="450"',
            tag,
            count=1,
            flags=re.I
        )

        if not re.search(r'\bheight\s*=', tag, re.I):
            tag = tag[:-1] + ' height="450">'

        return tag

    return re.sub(
        r'<canvas\b[^>]*>',
        fix_canvas,
        html,
        flags=re.I
    )


for file in game["files"]:
    path = file.get("path", "")
    content = file.get("content", "")

    if path == "index.html":
        content = normalize_canvas(content)

    file_path = os.path.join("generated", path)

    folder = os.path.dirname(file_path)

    if folder:
        os.makedirs(folder, exist_ok=True)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"✅ Generated: {path}")

print("\n🎉 GAME GENERATED SUCCESSFULLY")
print("📁 Location: ./generated/")
print("🖼️ Canvas normalized to 800x450")
