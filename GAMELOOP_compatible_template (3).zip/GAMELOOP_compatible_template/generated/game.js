const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const GW = 800, GH = 450;

const GRAVITY = 0.45;
const FLAP_FORCE = -7.5;
const PIPE_SPEED = 2.5;
const PIPE_WIDTH = 55;
const BASE_GAP = 145;
const PIPE_SPACING = 220;
const GROUND_H = 40;

let bird, pipes, score, gameState, frameCount, nextPipeAt;
let keys = {}, justPressed = {};

document.addEventListener('keydown', e => {
  if (!keys[e.code]) justPressed[e.code] = true;
  keys[e.code] = true;
  e.preventDefault();
});
document.addEventListener('keyup', e => { keys[e.code] = false; });

function init() {
  bird = { x: 120, y: GH / 2, vy: 0, w: 34, h: 26 };
  pipes = [];
  score = 0;
  frameCount = 0;
  nextPipeAt = 100;
  gameState = 'menu';
}

function flap() {
  bird.vy = FLAP_FORCE;
}

function getGapRange() {
  const r = Math.random();
  if (r < 0.2) return { minY: 30, maxY: GH - GROUND_H - BASE_GAP - 50 };
  if (r < 0.4) return { minY: 60, maxY: GH - GROUND_H - BASE_GAP - 30 };
  if (r < 0.6) return { minY: 80, maxY: GH - GROUND_H - BASE_GAP - 100 };
  if (r < 0.8) return { minY: 40, maxY: GH - GROUND_H - BASE_GAP - 40 };
  return { minY: 70, maxY: GH - GROUND_H - BASE_GAP - 60 };
}

function spawnPipe() {
  const range = getGapRange();
  const gapY = range.minY + Math.random() * Math.max(1, range.maxY - range.minY);
  const gapSize = BASE_GAP + (Math.random() - 0.5) * 30;
  pipes.push({ x: GW, gapY, gapSize: Math.max(100, gapSize), scored: false });
}

function update() {
  if (gameState === 'menu') {
    if (justPressed['Space'] || justPressed['ArrowUp'] || justPressed['KeyW']) {
      init(); gameState = 'playing';
    }
    return;
  }
  if (gameState !== 'playing') {
    if (justPressed['Space']) init();
    return;
  }

  if (justPressed['Space'] || justPressed['ArrowUp'] || justPressed['KeyW']) {
    flap();
  }
  justPressed = {};

  bird.vy += GRAVITY;
  bird.y += bird.vy;

  if (bird.y < 0) { bird.y = 0; bird.vy = Math.abs(bird.vy) * 0.3; }
  if (bird.y + bird.h > GH - GROUND_H) { gameState = 'gameover'; return; }

  frameCount++;
  if (frameCount >= nextPipeAt) { spawnPipe(); nextPipeAt = frameCount + PIPE_SPACING; }

  for (let i = pipes.length - 1; i >= 0; i--) {
    pipes[i].x -= PIPE_SPEED;
    if (!pipes[i].scored && pipes[i].x + PIPE_WIDTH < bird.x) {
      pipes[i].scored = true; score++;
    }
    if (pipes[i].x + PIPE_WIDTH < -10) pipes.splice(i, 1);
  }

  for (let p of pipes) {
    if (bird.x + bird.w > p.x && bird.x < p.x + PIPE_WIDTH) {
      if (bird.y < p.gapY || bird.y + bird.h > p.gapY + p.gapSize) {
        gameState = 'gameover'; return;
      }
    }
  }

  if (score >= 20) gameState = 'win';
}

function draw() {
  let grad = ctx.createLinearGradient(0, 0, 0, GH);
  grad.addColorStop(0, '#4FC3F7');
  grad.addColorStop(1, '#81D4FA');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, GW, GH);

  ctx.fillStyle = '#fff';
  for (let i = 0; i < 5; i++) {
    let cx = ((frameCount * 0.3 + i * 200) % (GW + 200)) - 100;
    let cy = 30 + i * 70;
    ctx.beginPath();
    ctx.arc(cx, cy, 25, 0, Math.PI * 2);
    ctx.arc(cx + 20, cy - 10, 20, 0, Math.PI * 2);
    ctx.arc(cx + 40, cy, 25, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.fillStyle = '#8BC34A';
  ctx.fillRect(0, GH - GROUND_H, GW, GROUND_H);
  ctx.fillStyle = '#689F38';
  ctx.fillRect(0, GH - GROUND_H, GW, 5);

  for (let p of pipes) {
    ctx.fillStyle = '#4CAF50';
    ctx.fillRect(p.x, 0, PIPE_WIDTH, p.gapY);
    ctx.fillStyle = '#66BB6A';
    ctx.fillRect(p.x - 4, p.gapY - 22, PIPE_WIDTH + 8, 22);
    ctx.fillStyle = '#4CAF50';
    ctx.fillRect(p.x, p.gapY + p.gapSize, PIPE_WIDTH, GH - GROUND_H - p.gapY - p.gapSize);
    ctx.fillStyle = '#66BB6A';
    ctx.fillRect(p.x - 4, p.gapY + p.gapSize, PIPE_WIDTH + 8, 22);
  }

  ctx.fillStyle = '#FFC107';
  ctx.beginPath();
  ctx.ellipse(bird.x + bird.w / 2, bird.y + bird.h / 2, bird.w / 2, bird.h / 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#FF9800';
  ctx.beginPath();
  ctx.arc(bird.x + bird.w - 5, bird.y + 9, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000';
  ctx.fillRect(bird.x + bird.w - 12, bird.y + 7, 5, 5);

  ctx.fillStyle = '#fff';
  ctx.font = 'bold 40px Arial';
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 4;
  ctx.strokeText(score, GW / 2 - 10, 55);
  ctx.fillText(score, GW / 2 - 10, 55);

  if (gameState === 'menu') {
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.fillRect(0, 0, GW, GH);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 52px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Flappy Bird', GW / 2, GH / 2 - 40);
    ctx.font = '22px Arial';
    ctx.fillText('SPACE / UP / W to Start', GW / 2, GH / 2 + 10);
    ctx.textAlign = 'left';
  }

  if (gameState === 'gameover') {
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(0, 0, GW, GH);
    ctx.fillStyle = '#F44336';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('GAME OVER', GW / 2, GH / 2 - 20);
    ctx.fillStyle = '#fff';
    ctx.font = '24px Arial';
    ctx.fillText('Score: ' + score, GW / 2, GH / 2 + 20);
    ctx.fillText('SPACE to Restart', GW / 2, GH / 2 + 55);
    ctx.textAlign = 'left';
  }

  if (gameState === 'win') {
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(0, 0, GW, GH);
    ctx.fillStyle = '#4CAF50';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('YOU WIN!', GW / 2, GH / 2 - 20);
    ctx.fillStyle = '#fff';
    ctx.font = '24px Arial';
    ctx.fillText('Score: ' + score, GW / 2, GH / 2 + 20);
    ctx.fillText('SPACE to Restart', GW / 2, GH / 2 + 55);
    ctx.textAlign = 'left';
  }
}

function loop() {
  update();
  draw();
  justPressed = {};
  requestAnimationFrame(loop);
}

init();
loop();