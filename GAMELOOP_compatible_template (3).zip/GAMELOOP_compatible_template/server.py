import json
import os
import subprocess
import threading
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))

job = {
    "running": False,
    "status": "idle",
    "logs": []
}


def add_log(message):
    print(message)
    job["logs"].append(message)


def run_process(command, stage):
    """
    Runs a backend process and streams its output into the monitor.
    Returns (return_code, output).
    """

    output = []

    process = subprocess.Popen(
        command,
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1
    )

    for line in process.stdout:
        line = line.strip()

        if line:
            output.append(line)
            add_log(line)

    process.wait()

    return process.returncode, "\n".join(output)


def run_generator(prompt):
    global job

    job["running"] = True
    job["status"] = "generating"
    job["logs"] = [
        "GAMELOOP AGENT STARTED",
        f"PROMPT: {prompt}",
        "GENERATING GAME..."
    ]

    try:

        # =========================================================
        # 1. GENERATE GAME
        # =========================================================

        generator_code, generator_output = run_process(
            [
                sys.executable,
                os.path.join("agent", "generator.py"),
                prompt
            ],
            "generator"
        )

        if generator_code != 0:
            job["status"] = "error"
            add_log("GAME GENERATION FAILED")
            return

        add_log("GAME GENERATION COMPLETE ✓")

        # =========================================================
        # 2. AUTOMATED PLAYTEST
        # =========================================================

        job["status"] = "testing"

        add_log("")
        add_log("================================")
        add_log("AUTOMATED PLAYTEST STARTED")
        add_log("================================")
        add_log("Launching autonomous tester...")

        tester_code, tester_output = run_process(
            [
                sys.executable,
                os.path.join("agent", "tester.py")
            ],
            "tester"
        )

        # =========================================================
        # 3. PLAYTEST PASSED
        # =========================================================

        if tester_code == 0:

            job["status"] = "verified"

            add_log("")
            add_log("PLAYTEST PASSED ✓")
            add_log("GAME VERIFIED ✓")
            add_log("AUTONOMOUS LOOP COMPLETE ✓")

            return

        # =========================================================
        # 4. BUG DETECTED
        # =========================================================

        job["status"] = "healing"

        add_log("")
        add_log("================================")
        add_log("BUG DETECTED")
        add_log("================================")

        add_log("Playtest failed.")
        add_log("Failure telemetry captured.")
        add_log("Sending failure to AI self-healing engine...")

        # =========================================================
        # 5. AI SELF-HEALING
        # =========================================================

        healer_code, healer_output = run_process(
            [
                sys.executable,
                os.path.join("agent", "healer.py"),
                tester_output
            ],
            "healer"
        )

        if healer_code != 0:

            job["status"] = "error"

            add_log("")
            add_log("SELF-HEALING FAILED ✗")
            add_log("Unable to automatically repair the game.")

            return

        add_log("")
        add_log("AUTONOMOUS PATCH COMPLETE ✓")

        # =========================================================
        # 6. RE-TEST
        # =========================================================

        job["status"] = "retesting"

        add_log("")
        add_log("================================")
        add_log("RE-VERIFICATION STARTED")
        add_log("================================")

        add_log("Launching tester again...")
        add_log("Testing repaired game...")

        retest_code, retest_output = run_process(
            [
                sys.executable,
                os.path.join("agent", "tester.py")
            ],
            "retester"
        )

        # =========================================================
        # 7. FINAL VERIFICATION
        # =========================================================

        if retest_code == 0:

            job["status"] = "verified"

            add_log("")
            add_log("RE-TEST PASSED ✓")
            add_log("GAME VERIFIED ✓")
            add_log("SELF-HEALING SUCCESSFUL ✓")
            add_log("")
            add_log("================================")
            add_log("GAMELOOP COMPLETE")
            add_log("================================")

        else:

            job["status"] = "error"

            add_log("")
            add_log("RE-TEST FAILED ✗")
            add_log("The repaired game still has issues.")

    except Exception as e:

        job["status"] = "error"

        add_log("")
        add_log("FATAL AGENT ERROR")
        add_log(str(e))

    finally:

        job["running"] = False


class Handler(BaseHTTPRequestHandler):

    def send_json(self, data):

        body = json.dumps(data).encode()

        self.send_response(200)

        self.send_header(
            "Content-Type",
            "application/json"
        )

        self.send_header(
            "Access-Control-Allow-Origin",
            "*"
        )

        self.send_header(
            "Content-Length",
            str(len(body))
        )

        self.end_headers()

        self.wfile.write(body)

    def do_POST(self):

        if self.path == "/api/generate":

            length = int(
                self.headers.get(
                    "Content-Length",
                    0
                )
            )

            body = self.rfile.read(length)

            data = json.loads(body)

            prompt = data.get(
                "prompt",
                ""
            ).strip()

            if not prompt:

                self.send_json({
                    "error": "Prompt is empty"
                })

                return

            if job["running"]:

                self.send_json({
                    "error": "Agent is already running"
                })

                return

            thread = threading.Thread(
                target=run_generator,
                args=(prompt,),
                daemon=True
            )

            thread.start()

            self.send_json({
                "started": True
            })

            return

        self.send_error(404)

    def do_GET(self):

        # =========================================================
        # STATUS API
        # =========================================================

        if self.path == "/api/status":

            self.send_json({
                "running": job["running"],
                "status": job["status"],
                "logs": job["logs"]
            })

            return

        # =========================================================
        # GENERATED GAME FILES
        # =========================================================

        if self.path.startswith("/generated/"):

            relative = self.path[len("/generated/"):]

            file_path = os.path.join(
                ROOT,
                "generated",
                relative
            )

            if os.path.isfile(file_path):

                with open(
                    file_path,
                    "rb"
                ) as f:

                    data = f.read()

                self.send_response(200)

                if file_path.endswith(".html"):
                    content_type = "text/html"

                elif file_path.endswith(".js"):
                    content_type = "text/javascript"

                elif file_path.endswith(".css"):
                    content_type = "text/css"

                else:
                    content_type = "application/octet-stream"

                self.send_header(
                    "Content-Type",
                    content_type
                )

                self.send_header(
                    "Content-Length",
                    str(len(data))
                )

                self.end_headers()

                self.wfile.write(data)

                return

        # =========================================================
        # MONITOR
        # =========================================================

        if self.path in [
            "/",
            "/monitor.html"
        ]:

            file_path = os.path.join(
                ROOT,
                "monitor.html"
            )

            if os.path.exists(file_path):

                with open(
                    file_path,
                    "rb"
                ) as f:

                    data = f.read()

                self.send_response(200)

                self.send_header(
                    "Content-Type",
                    "text/html"
                )

                self.send_header(
                    "Content-Length",
                    str(len(data))
                )

                self.end_headers()

                self.wfile.write(data)

                return

        self.send_error(404)


print()
print("================================")
print("       GAMELOOP AGENT SERVER")
print("================================")
print()
print("Open:")
print("http://127.0.0.1:8000/monitor.html")
print()

server = ThreadingHTTPServer(
    ("127.0.0.1", 8000),
    Handler
)

server.serve_forever()