// game.js
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Player properties
const player = {
  x: 100,
  y: 100,
  speed: 5,
  width: 30,
  height: 30
};

// Track pressed keys
const keys = {};

// Key event handlers – also prevent default scrolling
function handleKeyDown(e) {
  keys[e.key] = true;
  if (['w', 'a', 's', 'd', 'W', 'A', 'S', 'D'].includes(e.key)) {
    e.preventDefault();
  }
}

function handleKeyUp(e) {
  keys[e.key] = false;
}

window.addEventListener('keydown', handleKeyDown);
window.addEventListener('keyup', handleKeyUp);

function update() {
  // Move player based on current key state
  if (keys['w'] || keys['W']) player.y -= player.speed;
  if (keys['s'] || keys['S']) player.y += player.speed;
  if (keys['a'] || keys['A']) player.x -= player.speed;
  if (keys['d'] || keys['D']) player.x += player.speed;

  // Keep player within canvas bounds
  player.x = Math.max(0, Math.min(canvas.width - player.width, player.x));
  player.y = Math.max(0, Math.min(canvas.height - player.height, player.y));
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'steelblue';
  ctx.fillRect(player.x, player.y, player.width, player.height);
}

function gameLoop(timestamp) {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

function init() {
  // Resize canvas to fill the window
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  requestAnimationFrame(gameLoop);
}

window.addEventListener('load', init);
window.addEventListener('resize', init);