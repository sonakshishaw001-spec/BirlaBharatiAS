import os
import sys
import requests

API_KEY = os.getenv("OPENROUTER_API_KEY")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GENERATED_DIR = os.path.join(BASE_DIR, "generated")

failure = sys.argv[1] if len(sys.argv) > 1 else "Playtest failed."

print()
print("================================")
print("       GAMELOOP SELF-HEALER")
print("================================")
print()

files = {}

for filename in ["index.html", "game.js"]:
    path = os.path.join(GENERATED_DIR, filename)

    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            files[filename] = f.read()


prompt = f"""
You are the self-healing engineer for an autonomous game generation system.

A generated HTML/JavaScript game failed automated testing.

PLAYTEST FAILURE:
{failure}

CURRENT FILES:

===== index.html =====
{files.get("index.html", "")}

===== game.js =====
{files.get("game.js", "")}

Diagnose the actual failure and repair the game.

IMPORTANT:
- Preserve the existing game.
- Fix the actual reported failure.
- Do not remove working functionality.
- Return COMPLETE files, not patches.
- Make the smallest reliable fix possible.

DO NOT RETURN JSON.
DO NOT USE MARKDOWN CODE FENCES.

Return your answer using EXACTLY this structure:

===DIAGNOSIS===
short explanation of the bug and fix

===FILE:game.js===
FULL CORRECTED game.js HERE
===END_FILE===

If index.html also needs modification, additionally return:

===FILE:index.html===
FULL CORRECTED index.html HERE
===END_FILE===

If index.html does not need changes, do not return it.
"""


response = requests.post(
    "https://openrouter.ai/api/v1/chat/completions",
    headers={
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    },
    json={
        "model": "openrouter/free",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    },
    timeout=120
)

response.raise_for_status()

content = response.json()["choices"][0]["message"]["content"]

content = content.strip()


# =========================================================
# PARSE DIAGNOSIS
# =========================================================

diagnosis = "Bug diagnosed and repaired."

if "===DIAGNOSIS===" in content:

    diagnosis_part = content.split(
        "===DIAGNOSIS===",
        1
    )[1]

    if "===FILE:" in diagnosis_part:

        diagnosis = diagnosis_part.split(
            "===FILE:",
            1
        )[0].strip()

    else:
        diagnosis = diagnosis_part.strip()


print("[heal] Diagnosis:")
print(diagnosis)


# =========================================================
# PARSE FILES
# =========================================================

patched_any = False

marker = "===FILE:"

search_position = 0

while True:

    start = content.find(
        marker,
        search_position
    )

    if start == -1:
        break

    filename_start = start + len(marker)

    filename_end = content.find(
        "===",
        filename_start
    )

    if filename_end == -1:
        break

    filename = content[
        filename_start:filename_end
    ].strip()

    content_start = filename_end + 3

    end_marker = "===END_FILE==="

    content_end = content.find(
        end_marker,
        content_start
    )

    if content_end == -1:
        break

    file_content = content[
        content_start:content_end
    ].strip()

    if filename not in [
        "game.js",
        "index.html"
    ]:
        print(
            f"[heal] Ignoring unexpected file: {filename}"
        )

    else:

        path = os.path.join(
            GENERATED_DIR,
            filename
        )

        with open(
            path,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(file_content)

        print(
            f"[heal] Patched {filename} ✓"
        )

        patched_any = True

    search_position = content_end + len(
        end_marker
    )


# =========================================================
# RESULT
# =========================================================

if not patched_any:

    print()
    print("❌ SELF-HEALING FAILED")
    print("AI returned no valid repaired files.")
    sys.exit(1)


print()
print("✅ SELF-HEALING COMPLETE")