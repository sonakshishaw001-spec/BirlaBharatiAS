import sys
import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options

GAME_URL = "http://127.0.0.1:8000/generated/index.html"

print()
print("================================")
print("       GAMELOOP PLAYTESTER")
print("================================")
print()

options = Options()
options.add_argument("--window-size=1000,700")

options = Options()
options.binary_location = r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"
options.add_argument("--window-size=1000,700")
options.add_argument("--disable-gpu")

driver = webdriver.Chrome(options=options)

try:
    print("[playtest] Launching generated game...")
    driver.get(GAME_URL)
    time.sleep(2)

    print("[playtest] Game loaded ✓")

    # Check that the game has a canvas
    canvas = driver.find_elements(By.TAG_NAME, "canvas")

    if not canvas:
        print("[playtest] Canvas ✗ FAIL")
        print("❌ BUG DETECTED: No canvas found.")
        sys.exit(2)

    print("[playtest] Canvas detected ✓")

    # Focus the game
    canvas[0].click()

    print("[playtest] Testing WASD movement...")

    # Capture canvas before movement
    before = canvas[0].screenshot_as_png

    # Send real keyboard input
    ActionChains(driver) \
    .key_down("w") \
    .pause(0.5) \
    .key_up("w") \
    .perform()

    time.sleep(0.5)

    # Capture canvas after movement
    after = canvas[0].screenshot_as_png

    if before != after:
        print("[playtest] Movement detected ✓")
        movement_passed = True
    else:
        print("[playtest] Movement ✗ FAIL")
        movement_passed = False

    print()
    print("========== TEST RESULTS ==========")

    print("Game loads    ✓ PASS")
    print("Canvas        ✓ PASS")

    if movement_passed:
        print("Movement      ✓ PASS")
    else:
        print("Movement      ✗ FAIL")

    print()

    if not movement_passed:
        print("❌ BUG DETECTED")
        print()
        print("Failure:")
        print("WASD movement produced no observable change.")
        print()
        print("Sending failure telemetry to self-healing agent...")
        sys.exit(2)

    print("✅ PLAYTEST PASSED")

except Exception as e:
    print()
    print("❌ PLAYTEST ERROR")
    print(e)
    sys.exit(2)

finally:
    driver.quit()